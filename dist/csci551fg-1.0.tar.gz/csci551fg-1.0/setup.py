from setuptools import setup, find_packages

setup(
   name='csci551fg',
   version='1.0',
   packages=find_packages(),
   url='',
   license='',
   author='Frank',
   author_email='greguska@usc.edu',
   description='',
   include_package_data=True
)
